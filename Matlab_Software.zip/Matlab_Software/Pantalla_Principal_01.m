function varargout = Pantalla_Principal_01(varargin)
% PANTALLA_PRINCIPAL_01 MATLAB code for Pantalla_Principal_01.fig
%      PANTALLA_PRINCIPAL_01, by itself, creates a new PANTALLA_PRINCIPAL_01 or raises the existing
%      singleton*.
%
%      H = PANTALLA_PRINCIPAL_01 returns the handle to a new PANTALLA_PRINCIPAL_01 or the handle to
%      the existing singleton*.
%
%      PANTALLA_PRINCIPAL_01('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PANTALLA_PRINCIPAL_01.M with the given input arguments.
%
%      PANTALLA_PRINCIPAL_01('Property','Value',...) creates a new PANTALLA_PRINCIPAL_01 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Pantalla_Principal_01_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Pantalla_Principal_01_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Pantalla_Principal_01

% Last Modified by GUIDE v2.5 11-Apr-2022 13:09:24

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Pantalla_Principal_01_OpeningFcn, ...
                   'gui_OutputFcn',  @Pantalla_Principal_01_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Pantalla_Principal_01 is made visible.
function Pantalla_Principal_01_OpeningFcn(hObject, eventdata, handles, varargin)

handles.output = hObject;

%% Con este codigo se insertan las imagenes, primero definimos el handle y luego metemos las imagenes dentro de la carpeta donde se encuentre el codigo con su extensión

axes(handles.axes1)
imshow('Naturgy.jpg');
axes(handles.axes2)
imshow('LogoIberdrolaBueno.png');
axes(handles.axes3)
imshow('LogoBueno1.png');

%% En este apartado se indica que, al abrir la GUI, los distintos botones estarán deshabilitado  

set(handles.invinicial_editable,'String','');
set(handles.invinicial_editable,'Enable','Off');

set(handles.poblacionmax_editable,'String','');
set(handles.poblacionmax_editable,'Enable','Off');

set(handles.denspoblacionmax_editable,'String','');
set(handles.denspoblacionmax_editable,'Enable','Off');

%% Datos recopilados y boton de surtidores

Lista = ['1';'2';'3';'4'];
ListaPoblacion = ["Los Yébenes","Argés",'La Puebla de Montalbán','Villacañas','Mora','Consuegra','Madridejos','Quintanar de la Orden','Sonseca','Fuensalida','Ocaña','Torrijos','Illescas','Talavera de la Reina','Toledo'];
Poblacion=[5901,6418,7861,9548,9718,9998,10453,11030,11067,11370,11597,13466,28894,83417,84873];
ListaDensidadPoblacion = [8.7,270.3,55.6,35.6,57.6,27.9,39.9,125.5,185.8,166.3,78.4,776.6,503.8,448.9,366.2];
set(handles.surtidores_editable,'string',Lista);
set(handles.surtidores_editable,'Enable','Off');
guidata(hObject, handles);

% UIWAIT makes Pantalla_Principal_01 wait for user response (see UIRESUME)
% uiwait(handles.fondo01);


% --- Outputs from this function are returned to the command line.
function varargout = Pantalla_Principal_01_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;





function borrar_todo_Callback(hObject, eventdata, handles)

set(handles.invinicial_editable,'String','');
set(handles.invinicial_editable,'Enable','Off');

set(handles.poblacionmax_editable,'String','');
set(handles.poblacionmax_editable,'Enable','Off');

set(handles.denspoblacionmax_editable,'String','');
set(handles.denspoblacionmax_editable,'Enable','Off');

set(handles.surtidores_editable,'Enable','Off');

function aceptar_todo_Callback(hObject, eventdata, handles)

%% Comprobación de que todos los campos han sido rellenados

format longG
ArgumentoEntradaInversion = get(handles.invinicial_editable,'Enable');
ArgumentoEntradaPoblacion = get(handles.poblacionmax_editable,'Enable');
ArgumentoEntradaDensidad = get(handles.denspoblacionmax_editable,'Enable');
ArgumentoEntradaSurtidor = get(handles.surtidores_editable,'Enable');
if ArgumentoEntradaSurtidor == "off" || ArgumentoEntradaPoblacion == "off" || ArgumentoEntradaDensidad == "off" || ArgumentoEntradaInversion == "off"
    msgbox('Se necesitan rellenar todos los campos','','warn','modal',"FontSize",15);
else
    

NombreCiudadesP="0";
NombreCiudadesD="0";
%% -------------- CODIGO COMPARADOR POBLACION -------------- %%
ListaPoblacion = ["Los Yébenes","Argés",'La Puebla de Montalbán','Villacañas','Mora','Consuegra','Madridejos','Quintanar de la Orden','Sonseca','Fuensalida','Ocaña','Torrijos','Illescas','Talavera de la Reina','Toledo'];
Poblacion=[5901,6418,7861,9548,9718,9998,10453,11030,11067,11370,11597,13466,28894,83417,84873];

x=get(handles.poblacionmax_editable,'string');
xaux=str2num(x);
ListaPoblacion1=[];
ContadorPoblacion=1;
for i=1:length(Poblacion)
    if xaux >= Poblacion(i)
        ListaPoblacion1(ContadorPoblacion)=Poblacion(i);
        NombreCiudadesP(ContadorPoblacion)=ListaPoblacion(i);
        ContadorPoblacion=ContadorPoblacion+1;
    end
end

%% -------------- CODIGO COMPARADOR DENSIDAD POBLACION -------------- %%

ListaDensidadPoblacion = [8.7,270.3,55.6,35.6,57.6,27.9,39.9,125.5,185.8,166.3,78.4,776.6,503.8,448.9,366.2];
y=get(handles.denspoblacionmax_editable,'string');
yaux=str2num(y);
ListaDensidad=[];
ContadorDensidad=1;
for i=1:length(ListaDensidadPoblacion)
    if yaux >= ListaDensidadPoblacion(i)
        ListaDensidad(ContadorDensidad)=ListaDensidadPoblacion(i);
        NombreCiudadesD(ContadorDensidad)=ListaPoblacion(i);
        ContadorDensidad=ContadorDensidad+1;
    end
end

%% warning para ver valores minimos 

global numsurtidor
NumeroMinimoPoblacion = str2double(get(handles.poblacionmax_editable,'String'));
NumeroMinimoDensidadP = str2double(get(handles.denspoblacionmax_editable,'String'));
NumeroMinimoInversion = str2double(get(handles.invinicial_editable,'String'));
numsurtidor=get(handles.surtidores_editable,'value');
if NumeroMinimoPoblacion < 5901
    msgbox('La población mínima debe de ser 5.901 habitantes','','warn','modal');
elseif NumeroMinimoDensidadP < 8.7
    msgbox('La densidad de población mínima debe de ser 8.7 habitantes por kilometro cuadrado','','warn','modal');
elseif numsurtidor == 1 && NumeroMinimoInversion < 188543.73
    msgbox('El coste mínimo debe de ser 188.543,73 €','','warn','modal');
elseif numsurtidor == 2 && NumeroMinimoInversion < 237061.625
    msgbox('El coste mínimo debe de ser 237.061,625 €','','warn','modal');
elseif numsurtidor == 3 && NumeroMinimoInversion < 309703.31
    msgbox('El coste mínimo debe de ser 309.703,31 €','','warn','modal');
elseif numsurtidor == 4 && NumeroMinimoInversion < 361573.73
    msgbox('El coste mínimo debe de ser 361.573,73€','','warn','modal');
else
    
%% ----------------- SWITCH PARA VER LOS COSTES ------------------- %%
Listacostes=[];
switch numsurtidor
    case 1 
        costes1surtidor=fliplr([202906.35,203477.82,221436.4,221381.575,221549.275,221389.315,221373.19,221967.88,221653.12,188889.45,188735.295,188976.525,188700.465,188543.73,188760.45]);
        coste1=get(handles.invinicial_editable,'string');
        coste1=str2num(coste1);
        Listacostes1=[];
        Contadorcostes1=1;
        for i=1:length(costes1surtidor)
            if coste1 >= costes1surtidor(i)
            Listacostes(Contadorcostes1)=costes1surtidor(i);
            NombreCiudadesS(Contadorcostes1)=ListaPoblacion(i);
            Contadorcostes1=Contadorcostes1+1;
            end
        end

    case 2 
        costes2surtidor=fliplr([251424.245,251995.715,269954.295,269899.47,270067.17,269907.21,269891.085,270485.775,270171.015,237407.345,237253.19,237494.42,237218.36,237061.625,237278.345]);
        coste2=get(handles.invinicial_editable,'string');
        coste2=str2num(coste2);
        Listacostes2=[];
        Contadorcostes2=1;
        for i=1:length(costes2surtidor)
            if coste2 >= costes2surtidor(i)
               Listacostes(Contadorcostes2)=costes2surtidor(i);
               NombreCiudadesS(Contadorcostes2)=ListaPoblacion(i);
               Contadorcostes2=Contadorcostes2+1;
            end
        end

    case 3 
        costes3surtidor=fliplr([332517.385,328714.265,351841.06,351786.235,351953.935,351793.975,351777.85,352372.54,352057.78,310049.03,309894.875,310136.105,309860.045,309703.31,309920.03]);
        coste3=get(handles.invinicial_editable,'string');
        coste3=str2num(coste3);
        Listacostes3=[];
        Contadorcostes3=1;
        for i=1:length(costes3surtidor)
            if coste3 >= costes3surtidor(i)
               Listacostes(Contadorcostes3)=costes3surtidor(i);
               NombreCiudadesS(Contadorcostes3)=ListaPoblacion(i);
               Contadorcostes3=Contadorcostes3+1;
            end
        end

    case 4 
        costes4surtidor=fliplr([381713.51,381863,406182.46,406127.635,406295.335,406135.375,406119.25,406713.94,406399.18,362256.95,362102.795,362344.025,362067.965,361573.73,361790.45]);
        coste4=get(handles.invinicial_editable,'string');
        coste4=str2num(coste4);
        Listacostes4=[];
        Contadorcostes4=1;
        for i=1:length(costes4surtidor)
            if coste4 >= costes4surtidor(i)
               Listacostes(Contadorcostes4)=costes4surtidor(i);
               NombreCiudadesS(Contadorcostes4)=ListaPoblacion(i);
               Contadorcostes4=Contadorcostes4+1;
            end
        end
end



global EnviarGUISecundaria
EnviarGUISecundaria = "0";

%% ----------------- COMPARADOR DE RESTRICCIONES ------------------ %%
disp('NombreCiudadesP');
disp(NombreCiudadesP);
disp('NombreCiudadesD');
disp(NombreCiudadesD);
disp('NombreCiudadesS');
disp(NombreCiudadesS);

    contadorPrueba = 1;
    for a = 1 : length(ListaPoblacion1)
        for b = 1 : length(ListaDensidad)
            for c = 1 : length(Listacostes)
                if NombreCiudadesP(a) == NombreCiudadesD (b) &&  NombreCiudadesD (b) == NombreCiudadesS(c)
                   ValorPrueba = NombreCiudadesP(a);
                   EnviarGUISecundaria (contadorPrueba) = ValorPrueba;
                   contadorPrueba = contadorPrueba + 1;
                end
            end
        end
    end
    
disp ('EnviarGUISecundaria');
disp (EnviarGUISecundaria);
Pantalla_Secundaria_01;
end
end
% --- Executes on button press in invinicial.
function invinicial_Callback(hObject, eventdata, handles)
%% Solamente se podrá escribir cuando se pulse el botón 
set(handles.invinicial_editable,'String','');
set(handles.invinicial_editable,'Enable','On');

    


% --- Executes on button press in numerosurtidores.
function numerosurtidores_Callback(hObject, eventdata, handles)
%% Solamente se podrá elegir cuando se pulse el botón 
 Lista = ['1';'2';'3';'4'];
 set(handles.surtidores_editable,'string',Lista);
 set(handles.surtidores_editable,'Enable','On');


% --- Executes on button press in poblacionmax.
function poblacionmax_Callback(hObject, eventdata, handles)
%% Solamente se podrá escribir cuando se pulse el botón 
set(handles.poblacionmax_editable,'String','');
set(handles.poblacionmax_editable,'Enable','On');


% --- Executes on button press in denspoblacionmax.
function denspoblacionmax_Callback(hObject, eventdata, handles)
%% Solamente se podrá escribir cuando se pulse el botón 
set(handles.denspoblacionmax_editable,'String','');
set(handles.denspoblacionmax_editable,'Enable','On');


% --- Executes on selection change in surtidores_editable.
function surtidores_editable_Callback(hObject, eventdata, handles)
% hObject    handle to surtidores_editable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns surtidores_editable contents as cell array
%        contents{get(hObject,'Value')} returns selected item from surtidores_editable


% --- Executes during object creation, after setting all properties.
function surtidores_editable_CreateFcn(hObject, eventdata, handles)
% hObject    handle to surtidores_editable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function denspoblacionmax_editable_Callback(hObject, eventdata, handles)
% hObject    handle to denspoblacionmax_editable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of denspoblacionmax_editable as text
%        str2double(get(hObject,'String')) returns contents of denspoblacionmax_editable as a double


% --- Executes during object creation, after setting all properties.
function denspoblacionmax_editable_CreateFcn(hObject, eventdata, handles)
% hObject    handle to denspoblacionmax_editable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function poblacionmax_editable_Callback(hObject, eventdata, handles)
% hObject    handle to poblacionmax_editable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of poblacionmax_editable as text
%        str2double(get(hObject,'String')) returns contents of poblacionmax_editable as a double


% --- Executes during object creation, after setting all properties.
function poblacionmax_editable_CreateFcn(hObject, eventdata, handles)
% hObject    handle to poblacionmax_editable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function invinicial_editable_Callback(hObject, eventdata, handles)
% hObject    handle to invinicial_editable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of invinicial_editable as text
%        str2double(get(hObject,'String')) returns contents of invinicial_editable as a double


% --- Executes during object creation, after setting all properties.
function invinicial_editable_CreateFcn(hObject, eventdata, handles)
% hObject    handle to invinicial_editable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
