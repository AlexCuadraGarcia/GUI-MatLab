function varargout = Pantalla_Secundaria_01(varargin)

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Pantalla_Secundaria_01_OpeningFcn, ...
                   'gui_OutputFcn',  @Pantalla_Secundaria_01_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function Pantalla_Secundaria_01_OpeningFcn(hObject, eventdata, handles, varargin)

%% Lista de pueblos que cumplen las restricciones

global EnviarGUISecundaria
ListaBuena=[];
for i=1:length(EnviarGUISecundaria)
    ListaBuena(i)=(EnviarGUISecundaria(i));  
end  
set(handles.DesplegableCiudades,'string',EnviarGUISecundaria)

handles.output = hObject;

axes(handles.axes3)
imshow('Naturgy.jpg');
axes(handles.axes4)
imshow('LogoIberdrolaBueno.png');
axes(handles.axes6)
imshow('LogoBueno1.png');


guidata(hObject, handles);

% UIWAIT makes Pantalla_Secundaria_01 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Pantalla_Secundaria_01_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in DesplegableCiudades.
function DesplegableCiudades_Callback(hObject, eventdata, handles)

 
   



% --- Executes during object creation, after setting all properties.
function DesplegableCiudades_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DesplegableCiudades (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
 
% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in BotonAceptar.
function BotonAceptar_Callback(hObject, eventdata, handles)

%% Posicion de la ciudad dentro del popup

global EnviarGUISecundaria numero_ciudad
handles.Elige=EnviarGUISecundaria;
global Elige
Elige=handles.Elige;
handles.Elige=get(handles.DesplegableCiudades,'value');

disp('handles.Elige');
disp(handles.Elige);
numero_ciudad=handles.Elige;

Pantalla_Ciudades_General_01


% --- Executes on button press in BotonOptimizar.
function TiempoRecuperacion_Callback(hObject, eventdata, handles)

ListaCiudad = ["Los Yébenes","Argés",'La Puebla de Montalbán','Villacañas','Mora','Consuegra','Madridejos','Quintanar de la Orden','Sonseca','Fuensalida','Ocaña','Torrijos','Illescas','Talavera de la Reina','Toledo'];
global EnviarGUISecundaria numsurtidor
VectorAuxiliar=zeros(1,15);
%% switch comparador para graficar el tiempo de recuperación dependiendo del vector de municipios elegidos y también dependiendo del número de surtidor que hayas elegido 
switch numsurtidor
    case 1
        vectorPuntoscorte=[5.76,5.799,5.77,5.709,5.731,5.753,5.709,6.371,6.471,6.483,6.6,6.55,6.285,2.166,1.001];
        for i=1:length(ListaCiudad)
            for j=1:length(EnviarGUISecundaria)
                if ListaCiudad(i)==EnviarGUISecundaria(j)
                    VectorAuxiliar(i)=1;
                end
            end
        end
        contador=1;
        vectorhistograma=[];
        for k=1:length(VectorAuxiliar)
                if VectorAuxiliar(k)==1
                    vectorhistograma(contador)=vectorPuntoscorte(k);
                    contador=contador+1;
                end
        end
    case 2
        vectorPuntoscorte=[4.668,4.672,4.666,4.617,4.648,4.614,5.017,5.091,5.0882,5.187,5.142,5.155,4.944,1.732,0.805]; 
        for i=1:length(ListaCiudad)
            for j=1:length(EnviarGUISecundaria)
                if ListaCiudad(i)==EnviarGUISecundaria(j)
                    VectorAuxiliar(i)=1;
                end
            end
        end
        contador=1;
        vectorhistograma=[];
        for k=1:length(VectorAuxiliar)            
                if VectorAuxiliar(k)==1
                    vectorhistograma(contador)=vectorPuntoscorte(k);
                    contador=contador+1;
                end            
        end
    case 3
        vectorPuntoscorte=[4.498,4.503,4.497,4.447,4.476,4.445,4.83,4.897,4.893,4.989,4.945,4.965,4.752,1.669,0.786];        
        for i=1:length(ListaCiudad)
            for j=1:length(EnviarGUISecundaria)
                if ListaCiudad(i)==EnviarGUISecundaria(j)
                    VectorAuxiliar(i)=1;
                end
            end
        end
        contador=1;
        vectorhistograma=[];
        for k=1:length(VectorAuxiliar)
                if VectorAuxiliar(k)==1
                    vectorhistograma(contador)=vectorPuntoscorte(k);
                    contador=contador+1;
                end
        end
    case 4
        vectorPuntoscorte=[4.152,4.169,4.162,4.11,4.158,4.113,4.41,4.473,4.562,4.561,4.518,4.541,4.346,1.536,0.7154];
        for i=1:length(ListaCiudad)
            for j=1:length(EnviarGUISecundaria)
                if ListaCiudad(i)==EnviarGUISecundaria(j)
                    VectorAuxiliar(i)=1;
                end
            end
        end
        contador=1;
        vectorhistograma=[];
        for k=1:length(VectorAuxiliar)          
                if VectorAuxiliar(k)==1
                    vectorhistograma(contador)=vectorPuntoscorte(k);
                    contador=contador+1;
                end            
        end
end
%% Sacamos por pantalla el tiempo de recuperación de toda la lista de municipios mediante un diagrama de barras
figure
X=categorical(EnviarGUISecundaria);
X=reordercats(X,EnviarGUISecundaria);
bar(X,vectorhistograma,'blue');
title('Tiempo de recuperación');
ylabel('Años');
