function varargout = Pantalla_Ciudades_General_01(varargin)
% PANTALLA_CIUDADES_GENERAL_01 MATLAB code for Pantalla_Ciudades_General_01.fig
%      PANTALLA_CIUDADES_GENERAL_01, by itself, creates a new PANTALLA_CIUDADES_GENERAL_01 or raises the existing
%      singleton*.
%
%      H = PANTALLA_CIUDADES_GENERAL_01 returns the handle to a new PANTALLA_CIUDADES_GENERAL_01 or the handle to
%      the existing singleton*.
%
%      PANTALLA_CIUDADES_GENERAL_01('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PANTALLA_CIUDADES_GENERAL_01.M with the given input arguments.
%
%      PANTALLA_CIUDADES_GENERAL_01('Property','Value',...) creates a new PANTALLA_CIUDADES_GENERAL_01 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Pantalla_Ciudades_General_01_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Pantalla_Ciudades_General_01_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Pantalla_Ciudades_General_01

% Last Modified by GUIDE v2.5 29-Apr-2022 12:21:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Pantalla_Ciudades_General_01_OpeningFcn, ...
                   'gui_OutputFcn',  @Pantalla_Ciudades_General_01_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Pantalla_Ciudades_General_01 is made visible.
function Pantalla_Ciudades_General_01_OpeningFcn(hObject, eventdata, handles, varargin)

format longG
axes(handles.axes1)
imshow('Naturgy.jpg');
axes(handles.axes2)
imshow('LogoIberdrolaBueno.png');
axes(handles.axes4)
imshow('LogoBueno1.png');

global numero_ciudad EnviarGUISecundaria AccionInforme Ciudad Poblacion DensidadPoblacion CostesSurtidor
NumeroCiudad = numero_ciudad;
ListaCiudad = EnviarGUISecundaria;

disp('NumeroCiudad');
disp(NumeroCiudad);

%% Datos de las anteriores GUI
set(handles.CiudadNombre,'string',ListaCiudad(NumeroCiudad))
Poblacion=["5.901","6.418","7.861","9.548","9.718","9.998","10.453","11.030","11.067","11.370","11.597","13.466","28.894","83.417","84.873"];
DensidadPoblacion = ["8,7","270,3","55,6","35,6","57,6","27,9","39,9","125,5","185,58","166,3","78,4","776,6","503,8","448,9","366,2"];


%% --------------------- COSTES ---------------------- %%
global numsurtidor
disp('numsurtidor')
disp(numsurtidor)
switch numsurtidor
    case 1
        CostesSurtidor=fliplr(["202.906,35","203.477,82","221.436,4","221.381,575","221.549,275","221.389,315","221.373,19","221.967,88","221.653,12","188.889,45","188.735,295","188.976,525","188.700,465","188.543,73","188.760,45"]);
    case 2
        CostesSurtidor=fliplr(["251.424,245","251.995,715","269.954,295","269.899,47","270.067,17","269.907,21","269.891,085","270.485,775","270.171,015","237.407,345","237.253,19","237.494,42","237.218,36","237.061,625","237.278,345"]);
   case 3
        CostesSurtidor=fliplr(["332.517,385","328.714,265","351.841,06","351.786,235","351.953,935","351.793,975","351.777,85","352.372,54","352.057,78","310.049,03","309.894,875","310.136,105","309.860,045","309.703,31","309.920,03"]);
    case 4
        CostesSurtidor=fliplr(["381.713,51","381.863","406.182,46","406.127,635","406.295,335","406.135,375","406.119,25","406.713,94","406.399,18","362.256,95","362.102,795","362.344,025","362.067,965","361.573,73","361.790,45"]);
end
disp('CostesSurtidor');
disp(CostesSurtidor);
set(handles.CosteCiudad,'string',CostesSurtidor(NumeroCiudad));
set(handles.SurtidoresCiudad,'string',numsurtidor);
disp('EnviarGUISecundaria');
disp(EnviarGUISecundaria);

%% datos numéricos del municipio seleccionado
for i=1:length(EnviarGUISecundaria)
    if strcmp(EnviarGUISecundaria(i),"Los Yébenes")==1  && numero_ciudad==i 
        AccionInforme=1;
        Ciudad="Los Yébenes.";
        axes(handles.ubicacion)
        imshow("Yebenes.jpeg");
        set(handles.CoordenadasCiudad,'string','Coordenadas: 39,57744 -3,86715493');
        set(handles.PoblacionCiudad,'string',Poblacion(1));
        set(handles.DensidadCiudad,'string',DensidadPoblacion(1));
        set(handles.CosteCiudad,'string',CostesSurtidor(1));
    end
    if strcmp(EnviarGUISecundaria(i),"Argés")==1  && numero_ciudad==i
        Ciudad="Argés.";
        AccionInforme=2;
        axes(handles.ubicacion)
        imshow("Arges.jpeg");
        set(handles.CoordenadasCiudad,'string', 'Coordenadas: 39,81096 -4,058616');
        set(handles.PoblacionCiudad,'string',Poblacion(2));
        set(handles.DensidadCiudad,'string',DensidadPoblacion(2));
        set(handles.CosteCiudad,'string',CostesSurtidor(2));
    end
    if strcmp(EnviarGUISecundaria(i),"La Puebla de Montalbán")==1  && numero_ciudad==i
        Ciudad="La Puebla de Montalbán.";
        AccionInforme=3;
        axes(handles.ubicacion)
        imshow("Montalban.JPG");
        set(handles.CoordenadasCiudad,'string', 'Coordenadas: 39,8670095 -4,36572843');
        set(handles.PoblacionCiudad,'string',Poblacion(3));
        set(handles.DensidadCiudad,'string',DensidadPoblacion(3));
        set(handles.CosteCiudad,'string',CostesSurtidor(3));
    end
    if strcmp(EnviarGUISecundaria(i),"Villacañas")==1  && numero_ciudad==i
        Ciudad="Villacañas.";
        AccionInforme=4;
        axes(handles.ubicacion)
        imshow("Villacana.jpeg");
        set(handles.CoordenadasCiudad,'string', 'Coordenadas: 39,614135 -3,33638');
        set(handles.PoblacionCiudad,'string',Poblacion(4));
        set(handles.DensidadCiudad,'string',DensidadPoblacion(4));
        set(handles.CosteCiudad,'string',CostesSurtidor(4));
    end
    if strcmp(EnviarGUISecundaria(i),"Mora")==1  && numero_ciudad==i
        Ciudad="Mora.";
        AccionInforme=5;
        axes(handles.ubicacion)
        imshow("Mora.jpeg");
        set(handles.CoordenadasCiudad,'string', 'Coordenadas: 39,690242 -3,779905');
        set(handles.PoblacionCiudad,'string',Poblacion(5));
        set(handles.DensidadCiudad,'string',DensidadPoblacion(5));
        set(handles.CosteCiudad,'string',CostesSurtidor(5));
    end
    if strcmp(EnviarGUISecundaria(i),"Consuegra")==1  && numero_ciudad==i
       Ciudad="Consuegra."
       AccionInforme=6;
       axes(handles.ubicacion)
       imshow("consuegra.jpeg");
       set(handles.CoordenadasCiudad,'string', 'Coordenadas: 39,4668472 -3,6118324');
       set(handles.PoblacionCiudad,'string',Poblacion(6));
       set(handles.DensidadCiudad,'string',DensidadPoblacion(6));
       set(handles.CosteCiudad,'string',CostesSurtidor(6));
    end
    if strcmp(EnviarGUISecundaria(i),"Madridejos")==1  && numero_ciudad==i
        Ciudad="Madridejos.";
        AccionInforme=7;
        axes(handles.ubicacion)
        imshow("UbicacionMadridejos.JPG");
        set(handles.CoordenadasCiudad,'string', 'Coordenadas: 39,473867 -3,5372715');
        set(handles.PoblacionCiudad,'string',Poblacion(7));
        set(handles.DensidadCiudad,'string',DensidadPoblacion(7));
        set(handles.CosteCiudad,'string',CostesSurtidor(7));
    end
    if strcmp(EnviarGUISecundaria(i),"Quintanar de la Orden")==1  && numero_ciudad==i
        Ciudad="Quintanar de la Orden.";
        AccionInforme=8;
        axes(handles.ubicacion)
        imshow("UbicacionQuintanar.jpeg");
        set(handles.CoordenadasCiudad,'string', 'Coordenadas: 39,597873 -3,039476');
        set(handles.PoblacionCiudad,'string',Poblacion(8));
        set(handles.DensidadCiudad,'string',DensidadPoblacion(8));
        set(handles.CosteCiudad,'string',CostesSurtidor(8));
    end
    if strcmp(EnviarGUISecundaria(i),"Sonseca")==1  && numero_ciudad==i
        Ciudad="Sonseca.";
        AccionInforme=9;
        axes(handles.ubicacion)
        imshow("UbicacionSonseca.jpeg");
        set(handles.CoordenadasCiudad,'string', 'Coordenadas: 39,684711 -3,978336');
        set(handles.PoblacionCiudad,'string',Poblacion(9));
        set(handles.DensidadCiudad,'string',DensidadPoblacion(9));
        set(handles.CosteCiudad,'string',CostesSurtidor(9));
    end
    if strcmp(EnviarGUISecundaria(i),"Fuensalida")==1  && numero_ciudad==i
        Ciudad="Fuensalida.";
        AccionInforme=10;
        axes(handles.ubicacion)
        imshow("UbicacionFuensalida.jpeg");
        set(handles.CoordenadasCiudad,'string', 'Coordenadas: 40,05068 -4,20561');
        set(handles.PoblacionCiudad,'string',Poblacion(10));
        set(handles.DensidadCiudad,'string',DensidadPoblacion(10));
        set(handles.CosteCiudad,'string',CostesSurtidor(10));
    end
    if strcmp(EnviarGUISecundaria(i),"Ocaña")==1  && numero_ciudad==i
        Ciudad="Ocaña.";
        AccionInforme=11;
        axes(handles.ubicacion)
        imshow("UbicaciónOcana.JPG");
        set(handles.CoordenadasCiudad,'string', 'Coordenadas: 39,9603235 -3,4898359');
        set(handles.PoblacionCiudad,'string',Poblacion(11));
        set(handles.DensidadCiudad,'string',DensidadPoblacion(11));
        set(handles.CosteCiudad,'string',CostesSurtidor(11));
    end
    if strcmp(EnviarGUISecundaria(i),"Torrijos")==1  && numero_ciudad==i
        Ciudad="Torrijos.";
        AccionInforme=12;
        axes(handles.ubicacion)
        imshow("UbicacionTorrijos.jpeg");
        set(handles.CoordenadasCiudad,'string', 'Coordenadas: 39,990692 -4,280108');
        set(handles.PoblacionCiudad,'string',Poblacion(12));
        set(handles.DensidadCiudad,'string',DensidadPoblacion(12));
        set(handles.CosteCiudad,'string',CostesSurtidor(12));
    end
    if strcmp(EnviarGUISecundaria(i),"Illescas")==1  && numero_ciudad==i
        AccionInforme=13;
        Ciudad="Illescas.";
        axes(handles.ubicacion)
        imshow("UbicacionIllescas.PNG");
        set(handles.CoordenadasCiudad,'string', 'Coordenadas: 39,990692 -4,280108');
        set(handles.PoblacionCiudad,'string',Poblacion(13));
        set(handles.DensidadCiudad,'string',DensidadPoblacion(13));
        set(handles.CosteCiudad,'string',CostesSurtidor(13));
    end
    if strcmp(EnviarGUISecundaria(i),"Talavera de la Reina")==1  && numero_ciudad==i
        Ciudad="Talavera de la Reina.";
        AccionInforme=14;
        axes(handles.ubicacion)
        imshow("UbicacionTalavera.JPG");
        set(handles.CoordenadasCiudad,'string', 'Coordenadas: 40,126593 -4,842763');
        set(handles.PoblacionCiudad,'string',Poblacion(14));
        set(handles.DensidadCiudad,'string',DensidadPoblacion(14));
        set(handles.CosteCiudad,'string',CostesSurtidor(14));
    end
    if strcmp(EnviarGUISecundaria(i),"Toledo")==1  && numero_ciudad==i
        Ciudad="Toledo.";
        AccionInforme=15;
        axes(handles.ubicacion)
        imshow("UbicacionToledo.jpeg");
        set(handles.CoordenadasCiudad,'string', 'Coordenadas: 39,868628 -4,036178');
        set(handles.PoblacionCiudad,'string',Poblacion(15));
        set(handles.DensidadCiudad,'string',DensidadPoblacion(15));
        set(handles.CosteCiudad,'string',CostesSurtidor(15));
    end
end
disp('AccionInforme');
disp(AccionInforme);
handles.output = hObject;


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Pantalla_Ciudades_General_01 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Pantalla_Ciudades_General_01_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Graficar.
function Graficar_Callback(hObject, eventdata, handles)
global numsurtidor AccionInforme
%% Switch para delimitar los costes y beneficio según el número del surtidor 
switch numsurtidor
    case 1
        CostesSurtidorNumero=fliplr([202906.35,203477.82,221436.4,221381.575,221549.275,221389.315,221373.19,221967.88,221653.12,188889.45,188735.295,188976.525,188700.465,188543.73,188760.45]);
        BeneficioNumero=fliplr([201274.23	93601.6	35192.97	33684.26	33838.21	33530.31	34176.9	34238.48	34700.33	33160.83	32914.51	33160.83	32760.56	32698.98	32760.56]);
    case 2
        CostesSurtidorNumero=fliplr([251424.245,251995.715,269954.295,269899.47,270067.17,269907.21,269891.085,270485.775,270171.015,237407.345,237253.19,237494.42,237218.36,237061.625,237278.345]);
        BeneficioNumero=fliplr([312337.86	145251.2	54612.54	52271.32	52510.22	52032.42	53035.8	53131.36	53848.06	51459.06	51076.82	51459.06	50837.92	50742.36	50837.92]);
    case 3
        CostesSurtidorNumero=fliplr([332517.385	328714.265	351841.06	351786.235	351953.935	351793.975	351777.85	352372.54	352057.78	310049.03	309894.875	310136.105	309860.045	309703.31	309920.03]);
        BeneficioNumero=fliplr([423401.49	196900.8	74034	70860.19	71184.05	70536.33	71896.54	72026.08	72997.66	69759.07	69240.91	69759.07	68917.04	68787.5	68917.04]);
    case 4
        CostesSurtidorNumero=fliplr([381713.51	381863	406182.46	406127.635	406295.335	406135.375	406119.25	406713.94	406399.18	362256.95	362102.795	362344.025	362067.965	361573.73	361790.45]);
        BeneficioNumero=fliplr([534526.27	248578.84	93462.37	89455.67	89864.52	89046.83	90763.98	90927.52	92154.06	88065.59	87084.36	88065.59	87002.59	86839.05	87002.59]);
end
vcoste = zeros(1,9);
vbeneficio = zeros(1,9);
tiempo = 0:1:8;

%% Switch para graficar el coste frente al beneficio según el municipio seleccionado
switch AccionInforme
    case 1 %Los Yebenes
        vcoste(1) = CostesSurtidorNumero(AccionInforme);
        vbeneficio(1) = 0;
        for i=2:9
            vbeneficio(i) = (i-1)*BeneficioNumero(AccionInforme);
            vcoste(i) = CostesSurtidorNumero(AccionInforme);
        end
    case 2
        vcoste(1) = CostesSurtidorNumero(AccionInforme);
        vbeneficio(1) = 0;
        for i=2:9
            vbeneficio(i) = (i-1)*BeneficioNumero(AccionInforme);
            vcoste(i) = CostesSurtidorNumero(AccionInforme);
        end
    case 3
        vcoste(1) = CostesSurtidorNumero(AccionInforme);
        vbeneficio(1) = 0;
        for i=2:9
            vbeneficio(i) = (i-1)*BeneficioNumero(AccionInforme);
            vcoste(i) = CostesSurtidorNumero(AccionInforme);
        end
    case 4
        vcoste(1) = CostesSurtidorNumero(AccionInforme);
        vbeneficio(1) = 0;
        for i=2:9
            vbeneficio(i) = (i-1)*BeneficioNumero(AccionInforme);
            vcoste(i) = CostesSurtidorNumero(AccionInforme);
        end
    case 5
        vcoste(1) = CostesSurtidorNumero(AccionInforme);
        vbeneficio(1) = 0;
        for i=2:9
            vbeneficio(i) = (i-1)*BeneficioNumero(AccionInforme);
            vcoste(i) = CostesSurtidorNumero(AccionInforme);
        end
    case 6
        vcoste(1) = CostesSurtidorNumero(AccionInforme);
        vbeneficio(1) = 0;
        for i=2:9
            vbeneficio(i) = (i-1)*BeneficioNumero(AccionInforme);
            vcoste(i) = CostesSurtidorNumero(AccionInforme);
        end
    case 7
        vcoste(1) = CostesSurtidorNumero(AccionInforme);
        vbeneficio(1) = 0;
        for i=2:9
            vbeneficio(i) = (i-1)*BeneficioNumero(AccionInforme);
            vcoste(i) = CostesSurtidorNumero(AccionInforme);
        end
    case 8
        vcoste(1) = CostesSurtidorNumero(AccionInforme);
        vbeneficio(1) = 0;
        for i=2:9
            vbeneficio(i) = (i-1)*BeneficioNumero(AccionInforme);
            vcoste(i) = CostesSurtidorNumero(AccionInforme);
        end
    case 9
        vcoste(1) = CostesSurtidorNumero(AccionInforme);
        vbeneficio(1) = 0;
        for i=2:9
            vbeneficio(i) = (i-1)*BeneficioNumero(AccionInforme);
            vcoste(i) = CostesSurtidorNumero(AccionInforme);
        end
    case 10
        vcoste(1) = CostesSurtidorNumero(AccionInforme);
        vbeneficio(1) = 0;
        for i=2:9
            vbeneficio(i) = (i-1)*BeneficioNumero(AccionInforme);
            vcoste(i) = CostesSurtidorNumero(AccionInforme);
        end
    case 11
        vcoste(1) = CostesSurtidorNumero(AccionInforme);
        vbeneficio(1) = 0;
        for i=2:9
            vbeneficio(i) = (i-1)*BeneficioNumero(AccionInforme);
            vcoste(i) = CostesSurtidorNumero(AccionInforme);
        end
    case 12
        vcoste(1) = CostesSurtidorNumero(AccionInforme);
        vbeneficio(1) = 0;
        for i=2:9
            vbeneficio(i) = (i-1)*BeneficioNumero(AccionInforme);
            vcoste(i) = CostesSurtidorNumero(AccionInforme);
        end
    case 13
        vcoste(1) = CostesSurtidorNumero(AccionInforme);
        vbeneficio(1) = 0;
        for i=2:9
            vbeneficio(i) = (i-1)*BeneficioNumero(AccionInforme);
            vcoste(i) = CostesSurtidorNumero(AccionInforme);
        end
    case 14
        vcoste(1) = CostesSurtidorNumero(AccionInforme);
        vbeneficio(1) = 0;
        for i=2:9
            vbeneficio(i) = (i-1)*BeneficioNumero(AccionInforme);
            vcoste(i) = CostesSurtidorNumero(AccionInforme);
        end
    case 15
        vcoste(1) = CostesSurtidorNumero(AccionInforme);
        vbeneficio(1) = 0;
        for i=2:9
            vbeneficio(i) = (i-1)*BeneficioNumero(AccionInforme);
            vcoste(i) = CostesSurtidorNumero(AccionInforme);
        end
end
figure
plot(tiempo,vcoste,tiempo,vbeneficio,'LineWidth',1.2)
grid on
title('Coste vs Ingresos','FontSize',15,'FontWeight','bold');
xlabel('Años');
ylabel('Euros');
legend('Coste','Ingresos');
      
% --- Executes on button press in informe.
function informe_Callback(hObject, eventdata, handles)

%% Generación del informe 

fileID = fopen('Reporte.txt','w');

fprintf(fileID,'|-----------------------------------------------------------------------------|\n');
fprintf(fileID,'|---------------------------------- INFORME ----------------------------------|\n');
fprintf(fileID,'|-----------------------------------------------------------------------------|\n');
fprintf(fileID,'\n');

global AccionInforme Ciudad Poblacion DensidadPoblacion CostesSurtidor numsurtidor
vectorMetrosCuadrados=["529","529","678,5","713"];
CostesTransporte=["0","571.47","242.52","187.7","355.4","195.44","179.31","774","459.24","408.93","254.78","496.01","219.95","63.21","279.93"];
switch numsurtidor
    case 1
        CostesTerreno=["57.020,91","75.308,44","42.595,08"];
        CostesIguales=["57.020,91","30.025,94","3.988,49","10.877,9","358,33","26.945,5","411,21","0,1","7.406","20.143","30.380","4.358,99","2.800","84,9","4.605,08","3.500"];
        BeneficioAnual=["201.274,23","93.601,6","35.192,97","33.684,26","33.838,21","33.530,31","34.176,9","34.238,48","34.700,33","33.160,83","30.380","33.160,83","32.760,56","32.698,98","32.760,56"];
        VectorTiempoRec=["1 año","2 años, 1 mes y 29 días","6 años, 3 meses y 12 días","6 años, 6 meses y 17 días","6 años, 7 meses y 5 días","6 años, 5 meses y 23 días","6 años, 5 meses y 19 días","6 años, 4 meses y 13 días","5 años, 8 meses y 15 días","5 años, 9 meses y 1 día","5 años, 8 meses y 23 días","5 años, 8 meses y 15 días","5 años, 9 meses y 7 días","5 años, 9 meses y 17 días","5 años, 9 meses y 3 días"];
    case 2
        CostesTerreno=["57.020,91","75.308,44","42.595,08"];
        CostesIguales=["57.020,91","30.025,94","6.205,485","10.877,9","553,08","53.891","550,01","0,1","7.406","20.143","35.420","4.858,99","2.800","169,8","18.002,03","3.500"];
        VectorTiempoRec=["9 meses y 19 dias","1 año, 8 meses y 23 dias","4 años, 11 meses y 9 dias","5 años, 1 mes y 25 dias","5 años, 1 mes y 21 días","5 años, 2 meses y 7 días","5 años, 1 mes y 1 día","5 años, 1 mes y 2 días","5 años y 6 días","4 años, 7 meses y 11 días","4 años, 6 meses y 23 días","4 años, 7 meses y 12 días","4 años, 7 meses y 29 días","4 años, 8 meses y 1 día","4 años y 8 meses"];
        BeneficioAnual=["312.337,86","145.251,2","54.654,00","52.271,32","52.510,22","52.032,42","53.035,8","53.131,36","53.848,06","51.459,06","51.076,82","51.459,06","50.837,92","50.742,36","50.837,92"];
    case 3
        CostesTerreno=["73.135,515","96.591,26","54.632,82"];
        CostesIguales=["73.135,515","34.786,15","8.363,08","10.877,9","708,88","80.836,5","712,34","0,1","9.499","27.618","53.900","5.358,99","2.800","254,7","20.166,23","3.500"];
        VectorTiempoRec=["9 meses y 12 dias","1 año y 8 meses","4 años y 9 meses","4 años, 11 meses y 17 dias","4 años, 11 meses y 10 días","4 años, 11 meses y 26 días","4 años, 10 meses y 21 días","4 años, 10 meses y 22 días","4 años, 9 meses y 28 días","4 años, 5 meses y 10 días","4 años, 5 meses y 21 días","4 años, 5 meses y 10 días","4 años, 5 meses y 28 días","4 años, 6 meses y 1 día","4 años, 5 meses y 29 dias"];
        BeneficioAnual=["423.401,49","196.900,8","74.034","70.860,19","71.184,05","70.536,33","71.896,54","72.026,08","72.997,66","69.759,07","69.240,91","69.759,07","68.917,04","68.787,5","68.917,04"];
    case 4
        CostesTerreno=["76.854,27","101.502,68","57.410,76"];
        CostesIguales=["76.854,27","35.884,66","12.321,87","10.877,9","903,63","107.782","833,19","0,1","9.982","29.343","60.620","5.858,99","2.800","339,6","23.812,3","3.500"];
        VectorTiempoRec=["8 meses y 17 dias","1 año, 6 meses y 12 dias","4 años, 9 meses y 4 dias","4 años, 6 meses y 14 dias","4 años, 6 meses y 6 días","4 años, 6 meses y 21 días","4 años, 6 meses y 22 días","4 años, 5 meses y 20 días","4 años, 4 meses y 27 días","4 años, 1 mes y 10 días","4 años, 1 mes y 26 días","4 años, 1 mes y 9 días","4 años, 1 mes y 28 días","4 años y 2 meses","4 años, 1 mes y 24 dias"];
        BeneficioAnual=["534.526,27","248.578,84","93.462,37","89.455,67","89.864,52","89.046,83","90.763,98","90.927,52","92.154,06","88.065,59","87.084,36","88.065,59","87.002,59","86.839,05","87.002,59"];
end
switch AccionInforme
    case 1 %LOS YEBENES
        fprintf(fileID,strcat('MUNICIPIO SELECCIONADO:\t\t\t\t\t',Ciudad,'\n'));
        fprintf(fileID,strcat('POBLACIÓN (HABITANTES):\t\t\t\t\t',Poblacion(AccionInforme),'\n'));
        fprintf(fileID,strcat('DENSIDAD (HABITANTES POR KILOMETRO CUADRADO):\t\t',DensidadPoblacion(AccionInforme),'\n'));
        fprintf(fileID,'TOTAL SUMINISTRADORES:\t\t\t\t\t%d',numsurtidor);
        fprintf(fileID,'\n');
        fprintf(fileID,'METROS CUADRADOS TOTALES:\t\t\t\t%s',vectorMetrosCuadrados(numsurtidor));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|----------------- INVERSIÓN INICIAL DESGLOSADA (EUROS) ----------------------|\n\n');

        fprintf(fileID,strcat('Terreno:\t\t\t\t\t\t',CostesTerreno(3),'\n'));
        fprintf(fileID,strcat('Transporte:\t\t\t\t\t\t',CostesTransporte(15),'\n'));
        fprintf(fileID,strcat('Vallado:\t\t\t\t\t\t',CostesIguales(2),'\n'));
        fprintf(fileID,strcat('Estructura:\t\t\t\t\t\t',CostesIguales(3),'\n'));
        fprintf(fileID,strcat('Publicidad:\t\t\t\t\t\t',CostesIguales(4),'\n'));
        fprintf(fileID,strcat('Pintura y plantillas:\t\t\t\t\t',CostesIguales(5),'\n'));
        fprintf(fileID,strcat('Suministradores y conectores:\t\t\t\t',CostesIguales(6),'\n'));
        fprintf(fileID,strcat('Iluminación:\t\t\t\t\t\t',CostesIguales(7),'\n'));
        fprintf(fileID,strcat('Conexión a red:\t\t\t\t\t\t',CostesIguales(8),'\n'));
        fprintf(fileID,strcat('Acondicionamiento:\t\t\t\t\t',CostesIguales(9),'\n'));
        fprintf(fileID,strcat('Pavimentación y alquitranado:\t\t\t\t',CostesIguales(10),'\n'));
        fprintf(fileID,strcat('Maquinária y mano de obra:\t\t\t\t',CostesIguales(11),'\n'));
        fprintf(fileID,strcat('Mantenimiento:\t\t\t\t\t\t',CostesIguales(12),'\n'));
        fprintf(fileID,strcat('Electricista:\t\t\t\t\t\t',CostesIguales(13),'\n'));
        fprintf(fileID,strcat('Bolardos de separación:\t\t\t\t\t',CostesIguales(14),'\n'));
        fprintf(fileID,strcat('Electricidad:\t\t\t\t\t\t',CostesIguales(15),'\n'));
        fprintf(fileID,strcat('Seguridad:\t\t\t\t\t\t',CostesIguales(16),'\n'));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|--------------------------- DATOS DE INTERES --------------------------------|\n\n');
        
        fprintf(fileID,strcat('COSTE SIN AYUDAS (EUROS):\t\t\t\t',CostesSurtidor(AccionInforme),'\n'));
        fprintf(fileID,strcat('AYUDAS:\t\t\t\t\t\t\t35%% del coste inicial.\n'));
        fprintf(fileID,strcat('INGRESOS ANUALES(EUROS):\t\t\t\t',BeneficioAnual(15-AccionInforme+1),'\n'));
        fprintf(fileID,strcat('TIEMPO DE RECUPERACIÓN ESTIMADO:\t\t\t',VectorTiempoRec(15-AccionInforme+1),'\n'));
    case 2
        fprintf(fileID,strcat('MUNICIPIO SELECCIONADO:\t\t\t\t\t',Ciudad,'\n'));
        fprintf(fileID,strcat('POBLACIÓN (HABITANTES):\t\t\t\t\t',Poblacion(AccionInforme),'\n'));
        fprintf(fileID,strcat('DENSIDAD (HABITANTES POR KILOMETRO CUADRADO):\t\t',DensidadPoblacion(AccionInforme),'\n'));
        fprintf(fileID,'TOTAL SUMINISTRADORES:\t\t\t\t\t%d',numsurtidor);
        fprintf(fileID,'\n');
        fprintf(fileID,'METROS CUADRADOS TOTALES:\t\t\t\t%s',vectorMetrosCuadrados(numsurtidor));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|----------------- INVERSIÓN INICIAL DESGLOSADA (EUROS) ----------------------|\n\n');

        fprintf(fileID,strcat('Terreno:\t\t\t\t\t\t',CostesTerreno(3),'\n'));
        fprintf(fileID,strcat('Transporte:\t\t\t\t\t\t',CostesTransporte(14),'\n'));
        fprintf(fileID,strcat('Vallado:\t\t\t\t\t\t',CostesIguales(2),'\n'));
        fprintf(fileID,strcat('Estructura:\t\t\t\t\t\t',CostesIguales(3),'\n'));
        fprintf(fileID,strcat('Publicidad:\t\t\t\t\t\t',CostesIguales(4),'\n'));
        fprintf(fileID,strcat('Pintura y plantillas:\t\t\t\t\t',CostesIguales(5),'\n'));
        fprintf(fileID,strcat('Suministradores y conectores:\t\t\t\t',CostesIguales(6),'\n'));
        fprintf(fileID,strcat('Iluminación:\t\t\t\t\t\t',CostesIguales(7),'\n'));
        fprintf(fileID,strcat('Conexión a red:\t\t\t\t\t\t',CostesIguales(8),'\n'));
        fprintf(fileID,strcat('Acondicionamiento:\t\t\t\t\t',CostesIguales(9),'\n'));
        fprintf(fileID,strcat('Pavimentación y alquitranado:\t\t\t\t',CostesIguales(10),'\n'));
        fprintf(fileID,strcat('Maquinária y mano de obra:\t\t\t\t',CostesIguales(11),'\n'));
        fprintf(fileID,strcat('Mantenimiento:\t\t\t\t\t\t',CostesIguales(12),'\n'));
        fprintf(fileID,strcat('Electricista:\t\t\t\t\t\t',CostesIguales(13),'\n'));
        fprintf(fileID,strcat('Bolardos de separación:\t\t\t\t\t',CostesIguales(14),'\n'));
        fprintf(fileID,strcat('Electricidad:\t\t\t\t\t\t',CostesIguales(15),'\n'));
        fprintf(fileID,strcat('Seguridad:\t\t\t\t\t\t',CostesIguales(16),'\n'));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|--------------------------- DATOS DE INTERES --------------------------------|\n\n');
        
        fprintf(fileID,strcat('COSTE SIN AYUDAS (EUROS):\t\t\t\t',CostesSurtidor(AccionInforme),'\n'));
        fprintf(fileID,strcat('AYUDAS:\t\t\t\t\t\t\t35%% del coste inicial.\n'));
        fprintf(fileID,strcat('INGRESOS ANUALES(EUROS):\t\t\t\t',BeneficioAnual(15-AccionInforme+1),'\n'));
        fprintf(fileID,strcat('TIEMPO DE RECUPERACIÓN ESTIMADO:\t\t\t',VectorTiempoRec(15-AccionInforme+1),'\n'));
    case 3
        fprintf(fileID,strcat('MUNICIPIO SELECCIONADO:\t\t\t\t\t',Ciudad,'\n'));
        fprintf(fileID,strcat('POBLACIÓN (HABITANTES):\t\t\t\t\t',Poblacion(AccionInforme),'\n'));
        fprintf(fileID,strcat('DENSIDAD (HABITANTES POR KILOMETRO CUADRADO):\t\t',DensidadPoblacion(AccionInforme),'\n'));
        fprintf(fileID,'TOTAL SUMINISTRADORES:\t\t\t\t\t%d',numsurtidor);
        fprintf(fileID,'\n');
        fprintf(fileID,'METROS CUADRADOS TOTALES:\t\t\t\t%s',vectorMetrosCuadrados(numsurtidor));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|----------------- INVERSIÓN INICIAL DESGLOSADA (EUROS) ----------------------|\n\n');

        fprintf(fileID,strcat('Terreno:\t\t\t\t\t\t',CostesTerreno(3),'\n'));
        fprintf(fileID,strcat('Transporte:\t\t\t\t\t\t',CostesTransporte(13),'\n'));
        fprintf(fileID,strcat('Vallado:\t\t\t\t\t\t',CostesIguales(2),'\n'));
        fprintf(fileID,strcat('Estructura:\t\t\t\t\t\t',CostesIguales(3),'\n'));
        fprintf(fileID,strcat('Publicidad:\t\t\t\t\t\t',CostesIguales(4),'\n'));
        fprintf(fileID,strcat('Pintura y plantillas:\t\t\t\t\t',CostesIguales(5),'\n'));
        fprintf(fileID,strcat('Suministradores y conectores:\t\t\t\t',CostesIguales(6),'\n'));
        fprintf(fileID,strcat('Iluminación:\t\t\t\t\t\t',CostesIguales(7),'\n'));
        fprintf(fileID,strcat('Conexión a red:\t\t\t\t\t\t',CostesIguales(8),'\n'));
        fprintf(fileID,strcat('Acondicionamiento:\t\t\t\t\t',CostesIguales(9),'\n'));
        fprintf(fileID,strcat('Pavimentación y alquitranado:\t\t\t\t',CostesIguales(10),'\n'));
        fprintf(fileID,strcat('Maquinária y mano de obra:\t\t\t\t',CostesIguales(11),'\n'));
        fprintf(fileID,strcat('Mantenimiento:\t\t\t\t\t\t',CostesIguales(12),'\n'));
        fprintf(fileID,strcat('Electricista:\t\t\t\t\t\t',CostesIguales(13),'\n'));
        fprintf(fileID,strcat('Bolardos de separación:\t\t\t\t\t',CostesIguales(14),'\n'));
        fprintf(fileID,strcat('Electricidad:\t\t\t\t\t\t',CostesIguales(15),'\n'));
        fprintf(fileID,strcat('Seguridad:\t\t\t\t\t\t',CostesIguales(16),'\n'));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|--------------------------- DATOS DE INTERES --------------------------------|\n\n');
        
        fprintf(fileID,strcat('COSTE SIN AYUDAS (EUROS):\t\t\t\t',CostesSurtidor(AccionInforme),'\n'));
        fprintf(fileID,strcat('AYUDAS:\t\t\t\t\t\t\t35%% del coste inicial.\n'));
        fprintf(fileID,strcat('INGRESOS ANUALES(EUROS):\t\t\t\t',BeneficioAnual(15-AccionInforme+1),'\n'));
        fprintf(fileID,strcat('TIEMPO DE RECUPERACIÓN ESTIMADO:\t\t\t',VectorTiempoRec(15-AccionInforme+1),'\n'));
    case 4
        fprintf(fileID,strcat('MUNICIPIO SELECCIONADO:\t\t\t\t\t',Ciudad,'\n'));
        fprintf(fileID,strcat('POBLACIÓN (HABITANTES):\t\t\t\t\t',Poblacion(AccionInforme),'\n'));
        fprintf(fileID,strcat('DENSIDAD (HABITANTES POR KILOMETRO CUADRADO):\t\t',DensidadPoblacion(AccionInforme),'\n'));
        fprintf(fileID,'TOTAL SUMINISTRADORES:\t\t\t\t\t%d',numsurtidor);
        fprintf(fileID,'\n');
        fprintf(fileID,'METROS CUADRADOS TOTALES:\t\t\t\t%s',vectorMetrosCuadrados(numsurtidor));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|----------------- INVERSIÓN INICIAL DESGLOSADA (EUROS) ----------------------|\n\n');

        fprintf(fileID,strcat('Terreno:\t\t\t\t\t\t',CostesTerreno(3),'\n'));
        fprintf(fileID,strcat('Transporte:\t\t\t\t\t\t',CostesTransporte(12),'\n'));
        fprintf(fileID,strcat('Vallado:\t\t\t\t\t\t',CostesIguales(2),'\n'));
        fprintf(fileID,strcat('Estructura:\t\t\t\t\t\t',CostesIguales(3),'\n'));
        fprintf(fileID,strcat('Publicidad:\t\t\t\t\t\t',CostesIguales(4),'\n'));
        fprintf(fileID,strcat('Pintura y plantillas:\t\t\t\t\t',CostesIguales(5),'\n'));
        fprintf(fileID,strcat('Suministradores y conectores:\t\t\t\t',CostesIguales(6),'\n'));
        fprintf(fileID,strcat('Iluminación:\t\t\t\t\t\t',CostesIguales(7),'\n'));
        fprintf(fileID,strcat('Conexión a red:\t\t\t\t\t\t',CostesIguales(8),'\n'));
        fprintf(fileID,strcat('Acondicionamiento:\t\t\t\t\t',CostesIguales(9),'\n'));
        fprintf(fileID,strcat('Pavimentación y alquitranado:\t\t\t\t',CostesIguales(10),'\n'));
        fprintf(fileID,strcat('Maquinária y mano de obra:\t\t\t\t',CostesIguales(11),'\n'));
        fprintf(fileID,strcat('Mantenimiento:\t\t\t\t\t\t',CostesIguales(12),'\n'));
        fprintf(fileID,strcat('Electricista:\t\t\t\t\t\t',CostesIguales(13),'\n'));
        fprintf(fileID,strcat('Bolardos de separación:\t\t\t\t\t',CostesIguales(14),'\n'));
        fprintf(fileID,strcat('Electricidad:\t\t\t\t\t\t',CostesIguales(15),'\n'));
        fprintf(fileID,strcat('Seguridad:\t\t\t\t\t\t',CostesIguales(16),'\n'));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|--------------------------- DATOS DE INTERES --------------------------------|\n\n');
        
        fprintf(fileID,strcat('COSTE SIN AYUDAS (EUROS):\t\t\t\t',CostesSurtidor(AccionInforme),'\n'));
        fprintf(fileID,strcat('AYUDAS:\t\t\t\t\t\t\t35%% del coste inicial.\n'));
        fprintf(fileID,strcat('INGRESOS ANUALES(EUROS):\t\t\t\t',BeneficioAnual(15-AccionInforme+1),'\n'));
        fprintf(fileID,strcat('TIEMPO DE RECUPERACIÓN ESTIMADO:\t\t\t',VectorTiempoRec(15-AccionInforme+1),'\n'));
    case 5
        fprintf(fileID,strcat('MUNICIPIO SELECCIONADO:\t\t\t\t\t',Ciudad,'\n'));
        fprintf(fileID,strcat('POBLACIÓN (HABITANTES):\t\t\t\t\t',Poblacion(AccionInforme),'\n'));
        fprintf(fileID,strcat('DENSIDAD (HABITANTES POR KILOMETRO CUADRADO):\t\t',DensidadPoblacion(AccionInforme),'\n'));
        fprintf(fileID,'TOTAL SUMINISTRADORES:\t\t\t\t\t%d',numsurtidor);
        fprintf(fileID,'\n');
        fprintf(fileID,'METROS CUADRADOS TOTALES:\t\t\t\t%s',vectorMetrosCuadrados(numsurtidor));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|----------------- INVERSIÓN INICIAL DESGLOSADA (EUROS) ----------------------|\n\n');

        fprintf(fileID,strcat('Terreno:\t\t\t\t\t\t',CostesTerreno(3),'\n'));
        fprintf(fileID,strcat('Transporte:\t\t\t\t\t\t',CostesTransporte(11),'\n'));
        fprintf(fileID,strcat('Vallado:\t\t\t\t\t\t',CostesIguales(2),'\n'));
        fprintf(fileID,strcat('Estructura:\t\t\t\t\t\t',CostesIguales(3),'\n'));
        fprintf(fileID,strcat('Publicidad:\t\t\t\t\t\t',CostesIguales(4),'\n'));
        fprintf(fileID,strcat('Pintura y plantillas:\t\t\t\t\t',CostesIguales(5),'\n'));
        fprintf(fileID,strcat('Suministradores y conectores:\t\t\t\t',CostesIguales(6),'\n'));
        fprintf(fileID,strcat('Iluminación:\t\t\t\t\t\t',CostesIguales(7),'\n'));
        fprintf(fileID,strcat('Conexión a red:\t\t\t\t\t\t',CostesIguales(8),'\n'));
        fprintf(fileID,strcat('Acondicionamiento:\t\t\t\t\t',CostesIguales(9),'\n'));
        fprintf(fileID,strcat('Pavimentación y alquitranado:\t\t\t\t',CostesIguales(10),'\n'));
        fprintf(fileID,strcat('Maquinária y mano de obra:\t\t\t\t',CostesIguales(11),'\n'));
        fprintf(fileID,strcat('Mantenimiento:\t\t\t\t\t\t',CostesIguales(12),'\n'));
        fprintf(fileID,strcat('Electricista:\t\t\t\t\t\t',CostesIguales(13),'\n'));
        fprintf(fileID,strcat('Bolardos de separación:\t\t\t\t\t',CostesIguales(14),'\n'));
        fprintf(fileID,strcat('Electricidad:\t\t\t\t\t\t',CostesIguales(15),'\n'));
        fprintf(fileID,strcat('Seguridad:\t\t\t\t\t\t',CostesIguales(16),'\n'));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|--------------------------- DATOS DE INTERES --------------------------------|\n\n');
        
        fprintf(fileID,strcat('COSTE SIN AYUDAS (EUROS):\t\t\t\t',CostesSurtidor(AccionInforme),'\n'));
        fprintf(fileID,strcat('AYUDAS:\t\t\t\t\t\t\t35%% del coste inicial.\n'));
        fprintf(fileID,strcat('INGRESOS ANUALES(EUROS):\t\t\t\t',BeneficioAnual(15-AccionInforme+1),'\n'));
        fprintf(fileID,strcat('TIEMPO DE RECUPERACIÓN ESTIMADO:\t\t\t',VectorTiempoRec(15-AccionInforme+1),'\n'));
    case 6
        fprintf(fileID,strcat('MUNICIPIO SELECCIONADO:\t\t\t\t\t',Ciudad,'\n'));
        fprintf(fileID,strcat('POBLACIÓN (HABITANTES):\t\t\t\t\t',Poblacion(AccionInforme),'\n'));
        fprintf(fileID,strcat('DENSIDAD (HABITANTES POR KILOMETRO CUADRADO):\t\t',DensidadPoblacion(AccionInforme),'\n'));
        fprintf(fileID,'TOTAL SUMINISTRADORES:\t\t\t\t\t%d',numsurtidor);
        fprintf(fileID,'\n');
        fprintf(fileID,'METROS CUADRADOS TOTALES:\t\t\t\t%s',vectorMetrosCuadrados(numsurtidor));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|----------------- INVERSIÓN INICIAL DESGLOSADA (EUROS) ----------------------|\n\n');

        fprintf(fileID,strcat('Terreno:\t\t\t\t\t\t',CostesTerreno(3),'\n'));
        fprintf(fileID,strcat('Transporte:\t\t\t\t\t\t',CostesTransporte(10),'\n'));
        fprintf(fileID,strcat('Vallado:\t\t\t\t\t\t',CostesIguales(2),'\n'));
        fprintf(fileID,strcat('Estructura:\t\t\t\t\t\t',CostesIguales(3),'\n'));
        fprintf(fileID,strcat('Publicidad:\t\t\t\t\t\t',CostesIguales(4),'\n'));
        fprintf(fileID,strcat('Pintura y plantillas:\t\t\t\t\t',CostesIguales(5),'\n'));
        fprintf(fileID,strcat('Suministradores y conectores:\t\t\t\t',CostesIguales(6),'\n'));
        fprintf(fileID,strcat('Iluminación:\t\t\t\t\t\t',CostesIguales(7),'\n'));
        fprintf(fileID,strcat('Conexión a red:\t\t\t\t\t\t',CostesIguales(8),'\n'));
        fprintf(fileID,strcat('Acondicionamiento:\t\t\t\t\t',CostesIguales(9),'\n'));
        fprintf(fileID,strcat('Pavimentación y alquitranado:\t\t\t\t',CostesIguales(10),'\n'));
        fprintf(fileID,strcat('Maquinária y mano de obra:\t\t\t\t',CostesIguales(11),'\n'));
        fprintf(fileID,strcat('Mantenimiento:\t\t\t\t\t\t',CostesIguales(12),'\n'));
        fprintf(fileID,strcat('Electricista:\t\t\t\t\t\t',CostesIguales(13),'\n'));
        fprintf(fileID,strcat('Bolardos de separación:\t\t\t\t\t',CostesIguales(14),'\n'));
        fprintf(fileID,strcat('Electricidad:\t\t\t\t\t\t',CostesIguales(15),'\n'));
        fprintf(fileID,strcat('Seguridad:\t\t\t\t\t\t',CostesIguales(16),'\n'));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|--------------------------- DATOS DE INTERES --------------------------------|\n\n');
        
        fprintf(fileID,strcat('COSTE SIN AYUDAS (EUROS):\t\t\t\t',CostesSurtidor(AccionInforme),'\n'));
        fprintf(fileID,strcat('AYUDAS:\t\t\t\t\t\t\t35%% del coste inicial.\n'));
        fprintf(fileID,strcat('INGRESOS ANUALES(EUROS):\t\t\t\t',BeneficioAnual(15-AccionInforme+1),'\n'));
        fprintf(fileID,strcat('TIEMPO DE RECUPERACIÓN ESTIMADO:\t\t\t',VectorTiempoRec(15-AccionInforme+1),'\n'));
    case 7
        fprintf(fileID,strcat('MUNICIPIO SELECCIONADO:\t\t\t\t\t',Ciudad,'\n'));
        fprintf(fileID,strcat('POBLACIÓN (HABITANTES):\t\t\t\t\t',Poblacion(AccionInforme),'\n'));
        fprintf(fileID,strcat('DENSIDAD (HABITANTES POR KILOMETRO CUADRADO):\t\t',DensidadPoblacion(AccionInforme),'\n'));
        fprintf(fileID,'TOTAL SUMINISTRADORES:\t\t\t\t\t%d',numsurtidor);
        fprintf(fileID,'\n');
        fprintf(fileID,'METROS CUADRADOS TOTALES:\t\t\t\t%s',vectorMetrosCuadrados(numsurtidor));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|----------------- INVERSIÓN INICIAL DESGLOSADA (EUROS) ----------------------|\n\n');

        fprintf(fileID,strcat('Terreno:\t\t\t\t\t\t',CostesTerreno(2),'\n'));
        fprintf(fileID,strcat('Transporte:\t\t\t\t\t\t',CostesTransporte(9),'\n'));
        fprintf(fileID,strcat('Vallado:\t\t\t\t\t\t',CostesIguales(2),'\n'));
        fprintf(fileID,strcat('Estructura:\t\t\t\t\t\t',CostesIguales(3),'\n'));
        fprintf(fileID,strcat('Publicidad:\t\t\t\t\t\t',CostesIguales(4),'\n'));
        fprintf(fileID,strcat('Pintura y plantillas:\t\t\t\t\t',CostesIguales(5),'\n'));
        fprintf(fileID,strcat('Suministradores y conectores:\t\t\t\t',CostesIguales(6),'\n'));
        fprintf(fileID,strcat('Iluminación:\t\t\t\t\t\t',CostesIguales(7),'\n'));
        fprintf(fileID,strcat('Conexión a red:\t\t\t\t\t\t',CostesIguales(8),'\n'));
        fprintf(fileID,strcat('Acondicionamiento:\t\t\t\t\t',CostesIguales(9),'\n'));
        fprintf(fileID,strcat('Pavimentación y alquitranado:\t\t\t\t',CostesIguales(10),'\n'));
        fprintf(fileID,strcat('Maquinária y mano de obra:\t\t\t\t',CostesIguales(11),'\n'));
        fprintf(fileID,strcat('Mantenimiento:\t\t\t\t\t\t',CostesIguales(12),'\n'));
        fprintf(fileID,strcat('Electricista:\t\t\t\t\t\t',CostesIguales(13),'\n'));
        fprintf(fileID,strcat('Bolardos de separación:\t\t\t\t\t',CostesIguales(14),'\n'));
        fprintf(fileID,strcat('Electricidad:\t\t\t\t\t\t',CostesIguales(15),'\n'));
        fprintf(fileID,strcat('Seguridad:\t\t\t\t\t\t',CostesIguales(16),'\n'));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|--------------------------- DATOS DE INTERES --------------------------------|\n\n');
        
        fprintf(fileID,strcat('COSTE SIN AYUDAS (EUROS):\t\t\t\t',CostesSurtidor(AccionInforme),'\n'));
        fprintf(fileID,strcat('AYUDAS:\t\t\t\t\t\t\t35%% del coste inicial.\n'));
        fprintf(fileID,strcat('INGRESOS ANUALES(EUROS):\t\t\t\t',BeneficioAnual(15-AccionInforme+1),'\n'));
        fprintf(fileID,strcat('TIEMPO DE RECUPERACIÓN ESTIMADO:\t\t\t',VectorTiempoRec(15-AccionInforme+1),'\n'));
    case 8
        fprintf(fileID,strcat('MUNICIPIO SELECCIONADO:\t\t\t\t\t',Ciudad,'\n'));
        fprintf(fileID,strcat('POBLACIÓN (HABITANTES):\t\t\t\t\t',Poblacion(AccionInforme),'\n'));
        fprintf(fileID,strcat('DENSIDAD (HABITANTES POR KILOMETRO CUADRADO):\t\t',DensidadPoblacion(AccionInforme),'\n'));
        fprintf(fileID,'TOTAL SUMINISTRADORES:\t\t\t\t\t%d',numsurtidor);
        fprintf(fileID,'\n');
        fprintf(fileID,'METROS CUADRADOS TOTALES:\t\t\t\t%s',vectorMetrosCuadrados(numsurtidor));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|----------------- INVERSIÓN INICIAL DESGLOSADA (EUROS) ----------------------|\n\n');

        fprintf(fileID,strcat('Terreno:\t\t\t\t\t\t',CostesTerreno(2),'\n'));
        fprintf(fileID,strcat('Transporte:\t\t\t\t\t\t',CostesTransporte(8),'\n'));
        fprintf(fileID,strcat('Vallado:\t\t\t\t\t\t',CostesIguales(2),'\n'));
        fprintf(fileID,strcat('Estructura:\t\t\t\t\t\t',CostesIguales(3),'\n'));
        fprintf(fileID,strcat('Publicidad:\t\t\t\t\t\t',CostesIguales(4),'\n'));
        fprintf(fileID,strcat('Pintura y plantillas:\t\t\t\t\t',CostesIguales(5),'\n'));
        fprintf(fileID,strcat('Suministradores y conectores:\t\t\t\t',CostesIguales(6),'\n'));
        fprintf(fileID,strcat('Iluminación:\t\t\t\t\t\t',CostesIguales(7),'\n'));
        fprintf(fileID,strcat('Conexión a red:\t\t\t\t\t\t',CostesIguales(8),'\n'));
        fprintf(fileID,strcat('Acondicionamiento:\t\t\t\t\t',CostesIguales(9),'\n'));
        fprintf(fileID,strcat('Pavimentación y alquitranado:\t\t\t\t',CostesIguales(10),'\n'));
        fprintf(fileID,strcat('Maquinária y mano de obra:\t\t\t\t',CostesIguales(11),'\n'));
        fprintf(fileID,strcat('Mantenimiento:\t\t\t\t\t\t',CostesIguales(12),'\n'));
        fprintf(fileID,strcat('Electricista:\t\t\t\t\t\t',CostesIguales(13),'\n'));
        fprintf(fileID,strcat('Bolardos de separación:\t\t\t\t\t',CostesIguales(14),'\n'));
        fprintf(fileID,strcat('Electricidad:\t\t\t\t\t\t',CostesIguales(15),'\n'));
        fprintf(fileID,strcat('Seguridad:\t\t\t\t\t\t',CostesIguales(16),'\n'));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|--------------------------- DATOS DE INTERES --------------------------------|\n\n');
        
        fprintf(fileID,strcat('COSTE SIN AYUDAS (EUROS):\t\t\t\t',CostesSurtidor(AccionInforme),'\n'));
        fprintf(fileID,strcat('AYUDAS:\t\t\t\t\t\t\t35%% del coste inicial.\n'));
        fprintf(fileID,strcat('BENEFICIOS ANUALES(EUROS):\t\t\t\t',BeneficioAnual(15-AccionInforme+1),'\n'));
        fprintf(fileID,strcat('TIEMPO DE RECUPERACIÓN ESTIMADO:\t\t\t',VectorTiempoRec(15-AccionInforme+1),'\n'));
    case 9
        fprintf(fileID,strcat('MUNICIPIO SELECCIONADO:\t\t\t\t\t',Ciudad,'\n'));
        fprintf(fileID,strcat('POBLACIÓN (HABITANTES):\t\t\t\t\t',Poblacion(AccionInforme),'\n'));
        fprintf(fileID,strcat('DENSIDAD (HABITANTES POR KILOMETRO CUADRADO):\t\t',DensidadPoblacion(AccionInforme),'\n'));
        fprintf(fileID,'TOTAL SUMINISTRADORES:\t\t\t\t\t%d',numsurtidor);
        fprintf(fileID,'\n');
        fprintf(fileID,'METROS CUADRADOS TOTALES:\t\t\t\t%s',vectorMetrosCuadrados(numsurtidor));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|----------------- INVERSIÓN INICIAL DESGLOSADA (EUROS) ----------------------|\n\n');

        fprintf(fileID,strcat('Terreno:\t\t\t\t\t\t',CostesTerreno(2),'\n'));
        fprintf(fileID,strcat('Transporte:\t\t\t\t\t\t',CostesTransporte(7),'\n'));
        fprintf(fileID,strcat('Vallado:\t\t\t\t\t\t',CostesIguales(2),'\n'));
        fprintf(fileID,strcat('Estructura:\t\t\t\t\t\t',CostesIguales(3),'\n'));
        fprintf(fileID,strcat('Publicidad:\t\t\t\t\t\t',CostesIguales(4),'\n'));
        fprintf(fileID,strcat('Pintura y plantillas:\t\t\t\t\t',CostesIguales(5),'\n'));
        fprintf(fileID,strcat('Suministradores y conectores:\t\t\t\t',CostesIguales(6),'\n'));
        fprintf(fileID,strcat('Iluminación:\t\t\t\t\t\t',CostesIguales(7),'\n'));
        fprintf(fileID,strcat('Conexión a red:\t\t\t\t\t\t',CostesIguales(8),'\n'));
        fprintf(fileID,strcat('Acondicionamiento:\t\t\t\t\t',CostesIguales(9),'\n'));
        fprintf(fileID,strcat('Pavimentación y alquitranado:\t\t\t\t',CostesIguales(10),'\n'));
        fprintf(fileID,strcat('Maquinária y mano de obra:\t\t\t\t',CostesIguales(11),'\n'));
        fprintf(fileID,strcat('Mantenimiento:\t\t\t\t\t\t',CostesIguales(12),'\n'));
        fprintf(fileID,strcat('Electricista:\t\t\t\t\t\t',CostesIguales(13),'\n'));
        fprintf(fileID,strcat('Bolardos de separación:\t\t\t\t\t',CostesIguales(14),'\n'));
        fprintf(fileID,strcat('Electricidad:\t\t\t\t\t\t',CostesIguales(15),'\n'));
        fprintf(fileID,strcat('Seguridad:\t\t\t\t\t\t',CostesIguales(16),'\n'));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|--------------------------- DATOS DE INTERES --------------------------------|\n\n');
        
        fprintf(fileID,strcat('COSTE SIN AYUDAS (EUROS):\t\t\t\t',CostesSurtidor(AccionInforme),'\n'));
        fprintf(fileID,strcat('AYUDAS:\t\t\t\t\t\t\t35%% del coste inicial.\n'));
        fprintf(fileID,strcat('INGRESOS ANUALES(EUROS):\t\t\t\t',BeneficioAnual(15-AccionInforme+1),'\n'));
        fprintf(fileID,strcat('TIEMPO DE RECUPERACIÓN ESTIMADO:\t\t\t',VectorTiempoRec(15-AccionInforme+1),'\n'));
    case 10
        fprintf(fileID,strcat('MUNICIPIO SELECCIONADO:\t\t\t\t\t',Ciudad,'\n'));
        fprintf(fileID,strcat('POBLACIÓN (HABITANTES):\t\t\t\t\t',Poblacion(AccionInforme),'\n'));
        fprintf(fileID,strcat('DENSIDAD (HABITANTES POR KILOMETRO CUADRADO):\t\t',DensidadPoblacion(AccionInforme),'\n'));
        fprintf(fileID,'TOTAL SUMINISTRADORES:\t\t\t\t\t%d',numsurtidor);
        fprintf(fileID,'\n');
        fprintf(fileID,'METROS CUADRADOS TOTALES:\t\t\t\t%s',vectorMetrosCuadrados(numsurtidor));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|----------------- INVERSIÓN INICIAL DESGLOSADA (EUROS) ----------------------|\n\n');

        fprintf(fileID,strcat('Terreno:\t\t\t\t\t\t',CostesTerreno(2),'\n'));
        fprintf(fileID,strcat('Transporte:\t\t\t\t\t\t',CostesTransporte(6),'\n'));
        fprintf(fileID,strcat('Vallado:\t\t\t\t\t\t',CostesIguales(2),'\n'));
        fprintf(fileID,strcat('Estructura:\t\t\t\t\t\t',CostesIguales(3),'\n'));
        fprintf(fileID,strcat('Publicidad:\t\t\t\t\t\t',CostesIguales(4),'\n'));
        fprintf(fileID,strcat('Pintura y plantillas:\t\t\t\t\t',CostesIguales(5),'\n'));
        fprintf(fileID,strcat('Suministradores y conectores:\t\t\t\t',CostesIguales(6),'\n'));
        fprintf(fileID,strcat('Iluminación:\t\t\t\t\t\t',CostesIguales(7),'\n'));
        fprintf(fileID,strcat('Conexión a red:\t\t\t\t\t\t',CostesIguales(8),'\n'));
        fprintf(fileID,strcat('Acondicionamiento:\t\t\t\t\t',CostesIguales(9),'\n'));
        fprintf(fileID,strcat('Pavimentación y alquitranado:\t\t\t\t',CostesIguales(10),'\n'));
        fprintf(fileID,strcat('Maquinária y mano de obra:\t\t\t\t',CostesIguales(11),'\n'));
        fprintf(fileID,strcat('Mantenimiento:\t\t\t\t\t\t',CostesIguales(12),'\n'));
        fprintf(fileID,strcat('Electricista:\t\t\t\t\t\t',CostesIguales(13),'\n'));
        fprintf(fileID,strcat('Bolardos de separación:\t\t\t\t\t',CostesIguales(14),'\n'));
        fprintf(fileID,strcat('Electricidad:\t\t\t\t\t\t',CostesIguales(15),'\n'));
        fprintf(fileID,strcat('Seguridad:\t\t\t\t\t\t',CostesIguales(16),'\n'));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|--------------------------- DATOS DE INTERES --------------------------------|\n\n');
        
        fprintf(fileID,strcat('COSTE SIN AYUDAS (EUROS):\t\t\t\t',CostesSurtidor(AccionInforme),'\n'));
        fprintf(fileID,strcat('AYUDAS:\t\t\t\t\t\t\t35%% del coste inicial.\n'));
        fprintf(fileID,strcat('INGRESOS ANUALES(EUROS):\t\t\t\t',BeneficioAnual(15-AccionInforme+1),'\n'));
        fprintf(fileID,strcat('TIEMPO DE RECUPERACIÓN ESTIMADO:\t\t\t',VectorTiempoRec(15-AccionInforme+1),'\n'));
    case 11
        fprintf(fileID,strcat('MUNICIPIO SELECCIONADO:\t\t\t\t\t',Ciudad,'\n'));
        fprintf(fileID,strcat('POBLACIÓN (HABITANTES):\t\t\t\t\t',Poblacion(AccionInforme),'\n'));
        fprintf(fileID,strcat('DENSIDAD (HABITANTES POR KILOMETRO CUADRADO):\t\t',DensidadPoblacion(AccionInforme),'\n'));
        fprintf(fileID,'TOTAL SUMINISTRADORES:\t\t\t\t\t%d',numsurtidor);
        fprintf(fileID,'\n');
        fprintf(fileID,'METROS CUADRADOS TOTALES:\t\t\t\t%s',vectorMetrosCuadrados(numsurtidor));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|----------------- INVERSIÓN INICIAL DESGLOSADA (EUROS) ----------------------|\n\n');

        fprintf(fileID,strcat('Terreno:\t\t\t\t\t\t',CostesTerreno(2),'\n'));
        fprintf(fileID,strcat('Transporte:\t\t\t\t\t\t',CostesTransporte(5),'\n'));
        fprintf(fileID,strcat('Vallado:\t\t\t\t\t\t',CostesIguales(2),'\n'));
        fprintf(fileID,strcat('Estructura:\t\t\t\t\t\t',CostesIguales(3),'\n'));
        fprintf(fileID,strcat('Publicidad:\t\t\t\t\t\t',CostesIguales(4),'\n'));
        fprintf(fileID,strcat('Pintura y plantillas:\t\t\t\t\t',CostesIguales(5),'\n'));
        fprintf(fileID,strcat('Suministradores y conectores:\t\t\t\t',CostesIguales(6),'\n'));
        fprintf(fileID,strcat('Iluminación:\t\t\t\t\t\t',CostesIguales(7),'\n'));
        fprintf(fileID,strcat('Conexión a red:\t\t\t\t\t\t',CostesIguales(8),'\n'));
        fprintf(fileID,strcat('Acondicionamiento:\t\t\t\t\t',CostesIguales(9),'\n'));
        fprintf(fileID,strcat('Pavimentación y alquitranado:\t\t\t\t',CostesIguales(10),'\n'));
        fprintf(fileID,strcat('Maquinária y mano de obra:\t\t\t\t',CostesIguales(11),'\n'));
        fprintf(fileID,strcat('Mantenimiento:\t\t\t\t\t\t',CostesIguales(12),'\n'));
        fprintf(fileID,strcat('Electricista:\t\t\t\t\t\t',CostesIguales(13),'\n'));
        fprintf(fileID,strcat('Bolardos de separación:\t\t\t\t\t',CostesIguales(14),'\n'));
        fprintf(fileID,strcat('Electricidad:\t\t\t\t\t\t',CostesIguales(15),'\n'));
        fprintf(fileID,strcat('Seguridad:\t\t\t\t\t\t',CostesIguales(16),'\n'));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|--------------------------- DATOS DE INTERES --------------------------------|\n\n');
        
        fprintf(fileID,strcat('COSTE SIN AYUDAS (EUROS):\t\t\t\t',CostesSurtidor(AccionInforme),'\n'));
        fprintf(fileID,strcat('AYUDAS:\t\t\t\t\t\t\t35%% del coste inicial.\n'));
        fprintf(fileID,strcat('INGRESOS ANUALES(EUROS):\t\t\t\t',BeneficioAnual(15-AccionInforme+1),'\n'));
        fprintf(fileID,strcat('TIEMPO DE RECUPERACIÓN ESTIMADO:\t\t\t',VectorTiempoRec(15-AccionInforme+1),'\n'));
    case 12
        fprintf(fileID,strcat('MUNICIPIO SELECCIONADO:\t\t\t\t\t',Ciudad,'\n'));
        fprintf(fileID,strcat('POBLACIÓN (HABITANTES):\t\t\t\t\t',Poblacion(AccionInforme),'\n'));
        fprintf(fileID,strcat('DENSIDAD (HABITANTES POR KILOMETRO CUADRADO):\t\t',DensidadPoblacion(AccionInforme),'\n'));
        fprintf(fileID,'TOTAL SUMINISTRADORES:\t\t\t\t\t%d',numsurtidor);
        fprintf(fileID,'\n');
        fprintf(fileID,'METROS CUADRADOS TOTALES:\t\t\t\t%s',vectorMetrosCuadrados(numsurtidor));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|----------------- INVERSIÓN INICIAL DESGLOSADA (EUROS) ----------------------|\n\n');

        fprintf(fileID,strcat('Terreno:\t\t\t\t\t\t',CostesTerreno(2),'\n'));
        fprintf(fileID,strcat('Transporte:\t\t\t\t\t\t',CostesTransporte(4),'\n'));
        fprintf(fileID,strcat('Vallado:\t\t\t\t\t\t',CostesIguales(2),'\n'));
        fprintf(fileID,strcat('Estructura:\t\t\t\t\t\t',CostesIguales(3),'\n'));
        fprintf(fileID,strcat('Publicidad:\t\t\t\t\t\t',CostesIguales(4),'\n'));
        fprintf(fileID,strcat('Pintura y plantillas:\t\t\t\t\t',CostesIguales(5),'\n'));
        fprintf(fileID,strcat('Suministradores y conectores:\t\t\t\t',CostesIguales(6),'\n'));
        fprintf(fileID,strcat('Iluminación:\t\t\t\t\t\t',CostesIguales(7),'\n'));
        fprintf(fileID,strcat('Conexión a red:\t\t\t\t\t\t',CostesIguales(8),'\n'));
        fprintf(fileID,strcat('Acondicionamiento:\t\t\t\t\t',CostesIguales(9),'\n'));
        fprintf(fileID,strcat('Pavimentación y alquitranado:\t\t\t\t',CostesIguales(10),'\n'));
        fprintf(fileID,strcat('Maquinária y mano de obra:\t\t\t\t',CostesIguales(11),'\n'));
        fprintf(fileID,strcat('Mantenimiento:\t\t\t\t\t\t',CostesIguales(12),'\n'));
        fprintf(fileID,strcat('Electricista:\t\t\t\t\t\t',CostesIguales(13),'\n'));
        fprintf(fileID,strcat('Bolardos de separación:\t\t\t\t\t',CostesIguales(14),'\n'));
        fprintf(fileID,strcat('Electricidad:\t\t\t\t\t\t',CostesIguales(15),'\n'));
        fprintf(fileID,strcat('Seguridad:\t\t\t\t\t\t',CostesIguales(16),'\n'));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|--------------------------- DATOS DE INTERES --------------------------------|\n\n');
        
        fprintf(fileID,strcat('COSTE SIN AYUDAS (EUROS):\t\t\t\t',CostesSurtidor(AccionInforme),'\n'));
        fprintf(fileID,strcat('AYUDAS:\t\t\t\t\t\t\t35%% del coste inicial.\n'));
        fprintf(fileID,strcat('INGRESOS ANUALES(EUROS):\t\t\t\t',BeneficioAnual(15-AccionInforme+1),'\n'));
        fprintf(fileID,strcat('TIEMPO DE RECUPERACIÓN ESTIMADO:\t\t\t',VectorTiempoRec(15-AccionInforme+1),'\n'));
    case 13
        fprintf(fileID,strcat('MUNICIPIO SELECCIONADO:\t\t\t\t\t',Ciudad,'\n'));
        fprintf(fileID,strcat('POBLACIÓN (HABITANTES):\t\t\t\t\t',Poblacion(AccionInforme),'\n'));
        fprintf(fileID,strcat('DENSIDAD (HABITANTES POR KILOMETRO CUADRADO):\t\t',DensidadPoblacion(AccionInforme),'\n'));
        fprintf(fileID,'TOTAL SUMINISTRADORES:\t\t\t\t\t%d',numsurtidor);
        fprintf(fileID,'\n');
        fprintf(fileID,'METROS CUADRADOS TOTALES:\t\t\t\t%s',vectorMetrosCuadrados(numsurtidor));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|----------------- INVERSIÓN INICIAL DESGLOSADA (EUROS) ----------------------|\n\n');

        fprintf(fileID,strcat('Terreno:\t\t\t\t\t\t',CostesTerreno(2),'\n'));
        fprintf(fileID,strcat('Transporte:\t\t\t\t\t\t',CostesTransporte(3),'\n'));
        fprintf(fileID,strcat('Vallado:\t\t\t\t\t\t',CostesIguales(2),'\n'));
        fprintf(fileID,strcat('Estructura:\t\t\t\t\t\t',CostesIguales(3),'\n'));
        fprintf(fileID,strcat('Publicidad:\t\t\t\t\t\t',CostesIguales(4),'\n'));
        fprintf(fileID,strcat('Pintura y plantillas:\t\t\t\t\t',CostesIguales(5),'\n'));
        fprintf(fileID,strcat('Suministradores y conectores:\t\t\t\t',CostesIguales(6),'\n'));
        fprintf(fileID,strcat('Iluminación:\t\t\t\t\t\t',CostesIguales(7),'\n'));
        fprintf(fileID,strcat('Conexión a red:\t\t\t\t\t\t',CostesIguales(8),'\n'));
        fprintf(fileID,strcat('Acondicionamiento:\t\t\t\t\t',CostesIguales(9),'\n'));
        fprintf(fileID,strcat('Pavimentación y alquitranado:\t\t\t\t',CostesIguales(10),'\n'));
        fprintf(fileID,strcat('Maquinária y mano de obra:\t\t\t\t',CostesIguales(11),'\n'));
        fprintf(fileID,strcat('Mantenimiento:\t\t\t\t\t\t',CostesIguales(12),'\n'));
        fprintf(fileID,strcat('Electricista:\t\t\t\t\t\t',CostesIguales(13),'\n'));
        fprintf(fileID,strcat('Bolardos de separación:\t\t\t\t\t',CostesIguales(14),'\n'));
        fprintf(fileID,strcat('Electricidad:\t\t\t\t\t\t',CostesIguales(15),'\n'));
        fprintf(fileID,strcat('Seguridad:\t\t\t\t\t\t',CostesIguales(16),'\n'));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|--------------------------- DATOS DE INTERES --------------------------------|\n\n');
        
        fprintf(fileID,strcat('COSTE SIN AYUDAS (EUROS):\t\t\t\t',CostesSurtidor(AccionInforme),'\n'));
        fprintf(fileID,strcat('AYUDAS:\t\t\t\t\t\t\t35%% del coste inicial.\n'));
        fprintf(fileID,strcat('INGRESOS ANUALES(EUROS):\t\t\t\t',BeneficioAnual(15-AccionInforme+1),'\n'));
        fprintf(fileID,strcat('TIEMPO DE RECUPERACIÓN ESTIMADO:\t\t\t',VectorTiempoRec(15-AccionInforme+1),'\n'));
    case 14
        fprintf(fileID,strcat('MUNICIPIO SELECCIONADO:\t\t\t\t\t',Ciudad,'\n'));
        fprintf(fileID,strcat('POBLACIÓN (HABITANTES):\t\t\t\t\t',Poblacion(AccionInforme),'\n'));
        fprintf(fileID,strcat('DENSIDAD (HABITANTES POR KILOMETRO CUADRADO):\t\t',DensidadPoblacion(AccionInforme),'\n'));
        fprintf(fileID,'TOTAL SUMINISTRADORES:\t\t\t\t\t%d',numsurtidor);
        fprintf(fileID,'\n');
        fprintf(fileID,'METROS CUADRADOS TOTALES:\t\t\t\t%s',vectorMetrosCuadrados(numsurtidor));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|----------------- INVERSIÓN INICIAL DESGLOSADA (EUROS) ----------------------|\n\n');

        fprintf(fileID,strcat('Terreno:\t\t\t\t\t\t',CostesTerreno(1),'\n'));
        fprintf(fileID,strcat('Transporte:\t\t\t\t\t\t',CostesTransporte(2),'\n'));
        fprintf(fileID,strcat('Vallado:\t\t\t\t\t\t',CostesIguales(2),'\n'));
        fprintf(fileID,strcat('Estructura:\t\t\t\t\t\t',CostesIguales(3),'\n'));
        fprintf(fileID,strcat('Publicidad:\t\t\t\t\t\t',CostesIguales(4),'\n'));
        fprintf(fileID,strcat('Pintura y plantillas:\t\t\t\t\t',CostesIguales(5),'\n'));
        fprintf(fileID,strcat('Suministradores y conectores:\t\t\t\t',CostesIguales(6),'\n'));
        fprintf(fileID,strcat('Iluminación:\t\t\t\t\t\t',CostesIguales(7),'\n'));
        fprintf(fileID,strcat('Conexión a red:\t\t\t\t\t\t',CostesIguales(8),'\n'));
        fprintf(fileID,strcat('Acondicionamiento:\t\t\t\t\t',CostesIguales(9),'\n'));
        fprintf(fileID,strcat('Pavimentación y alquitranado:\t\t\t\t',CostesIguales(10),'\n'));
        fprintf(fileID,strcat('Maquinária y mano de obra:\t\t\t\t',CostesIguales(11),'\n'));
        fprintf(fileID,strcat('Mantenimiento:\t\t\t\t\t\t',CostesIguales(12),'\n'));
        fprintf(fileID,strcat('Electricista:\t\t\t\t\t\t',CostesIguales(13),'\n'));
        fprintf(fileID,strcat('Bolardos de separación:\t\t\t\t\t',CostesIguales(14),'\n'));
        fprintf(fileID,strcat('Electricidad:\t\t\t\t\t\t',CostesIguales(15),'\n'));
        fprintf(fileID,strcat('Seguridad:\t\t\t\t\t\t',CostesIguales(16),'\n'));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|--------------------------- DATOS DE INTERES --------------------------------|\n\n');
        
        fprintf(fileID,strcat('COSTE SIN AYUDAS (EUROS):\t\t\t\t',CostesSurtidor(AccionInforme),'\n'));
        fprintf(fileID,strcat('AYUDAS:\t\t\t\t\t\t\t35%% del coste inicial.\n'));
        fprintf(fileID,strcat('INGRESOS ANUALES(EUROS):\t\t\t\t',BeneficioAnual(15-AccionInforme+1),'\n'));
        fprintf(fileID,strcat('TIEMPO DE RECUPERACIÓN ESTIMADO:\t\t\t',VectorTiempoRec(15-AccionInforme+1),'\n'));
    case 15
        fprintf(fileID,strcat('MUNICIPIO SELECCIONADO:\t\t\t\t\t',Ciudad,'\n'));
        fprintf(fileID,strcat('POBLACIÓN (HABITANTES):\t\t\t\t\t',Poblacion(AccionInforme),'\n'));
        fprintf(fileID,strcat('DENSIDAD (HABITANTES POR KILOMETRO CUADRADO):\t\t',DensidadPoblacion(AccionInforme),'\n'));
        fprintf(fileID,'TOTAL SUMINISTRADORES:\t\t\t\t\t%d',numsurtidor);
        fprintf(fileID,'\n');
        fprintf(fileID,'METROS CUADRADOS TOTALES:\t\t\t\t%s',vectorMetrosCuadrados(numsurtidor));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|----------------- INVERSIÓN INICIAL DESGLOSADA (EUROS) ----------------------|\n\n');

        fprintf(fileID,strcat('Terreno:\t\t\t\t\t\t',CostesTerreno(1),'\n'));
        fprintf(fileID,strcat('Transporte:\t\t\t\t\t\t',CostesTransporte(1),'\n'));
        fprintf(fileID,strcat('Vallado:\t\t\t\t\t\t',CostesIguales(2),'\n'));
        fprintf(fileID,strcat('Estructura:\t\t\t\t\t\t',CostesIguales(3),'\n'));
        fprintf(fileID,strcat('Publicidad:\t\t\t\t\t\t',CostesIguales(4),'\n'));
        fprintf(fileID,strcat('Pintura y plantillas:\t\t\t\t\t',CostesIguales(5),'\n'));
        fprintf(fileID,strcat('Suministradores y conectores:\t\t\t\t',CostesIguales(6),'\n'));
        fprintf(fileID,strcat('Iluminación:\t\t\t\t\t\t',CostesIguales(7),'\n'));
        fprintf(fileID,strcat('Conexión a red:\t\t\t\t\t\t',CostesIguales(8),'\n'));
        fprintf(fileID,strcat('Acondicionamiento:\t\t\t\t\t',CostesIguales(9),'\n'));
        fprintf(fileID,strcat('Pavimentación y alquitranado:\t\t\t\t',CostesIguales(10),'\n'));
        fprintf(fileID,strcat('Maquinária y mano de obra:\t\t\t\t',CostesIguales(11),'\n'));
        fprintf(fileID,strcat('Mantenimiento:\t\t\t\t\t\t',CostesIguales(12),'\n'));
        fprintf(fileID,strcat('Electricista:\t\t\t\t\t\t',CostesIguales(13),'\n'));
        fprintf(fileID,strcat('Bolardos de separación:\t\t\t\t\t',CostesIguales(14),'\n'));
        fprintf(fileID,strcat('Electricidad:\t\t\t\t\t\t',CostesIguales(15),'\n'));
        fprintf(fileID,strcat('Seguridad:\t\t\t\t\t\t',CostesIguales(16),'\n'));
        fprintf(fileID,'\n\n\n');
        
        fprintf(fileID,'|--------------------------- DATOS DE INTERES --------------------------------|\n\n');
        
        fprintf(fileID,strcat('COSTE SIN AYUDAS (EUROS):\t\t\t\t',CostesSurtidor(AccionInforme),'\n'));
        fprintf(fileID,strcat('AYUDAS:\t\t\t\t\t\t\t35%% del coste inicial.\n'));
        fprintf(fileID,strcat('INGRESOS ANUALES(EUROS):\t\t\t\t',BeneficioAnual(15-AccionInforme+1),'\n'));
        fprintf(fileID,strcat('TIEMPO DE RECUPERACIÓN ESTIMADO:\t\t\t',VectorTiempoRec(15-AccionInforme+1),'\n'));

        
end
fclose(fileID);
[F,D]=uigetfile('*.txt*','Seleccionar Reporte.txt');
winopen(F);


% --- Executes on button press in Plano.
function Plano_Callback(hObject, eventdata, handles)

Pantalla_Plano
